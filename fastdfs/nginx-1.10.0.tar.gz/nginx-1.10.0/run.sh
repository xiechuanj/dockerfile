#!/bin/bash
### BEGIN INIT INFO 
# Provides: Nginx
# Required-Start: $all 
# Required-Stop: $all 
# Default-Start: 3 5 
# Default-Stop: 0 1 6 
# Short-Description: Start and stop nginx mode 
# Description: Start and stop nginx in external FASTCGI mode 
### END INIT INFO 
# chkconfig: 2345 90 10
# description: nginx server daemon

#set -e

mode=$1
dir=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

# Source networking configuration. 
. /etc/sysconfig/network
# Check that networking is up. 
[ "$NETWORKING" = "no" ] && exit 0

chk_pid()
{
    if [ ! -f $dir/logs/nginx.pid ];then
        return 1
    else
        kill -0 `cat $dir/logs/nginx.pid` >/dev/null 2>&1
        if [ $? -ne 0 ];then
	    return 1
	else
	    return 0
	fi
    fi
}

start()
{
    chk_pid
    if [ $? -eq 0 ];then
        echo "already running,pid is `cat $dir/logs/nginx.pid` in pidfile $dir/logs/nginx.pid"
	exit 4
    fi
    $dir/sbin/nginx -p $dir
    resv=$?
    return $resv
}
stop()
{
    $dir/sbin/nginx -p $dir -s stop
    resv=$?
    return $resv
}
reload()
{
    $dir/sbin/nginx -p $dir -s reload
    resv=$?
    return $resv
}

restart()
{
    stop
    start
}
check()
{
    $dir/sbin/nginx -p $dir -t
}

case $mode in
    'start')
	start
    ;;
    'stop')
	stop
    ;;
    'reload')
	reload
    ;;
    'restart')
	restart
    ;;
    'check')
	check
    ;;
    *)
	echo "Usage: $0 {start|stop|restart|reload|check}"
	exit 2
    ;;
esac
